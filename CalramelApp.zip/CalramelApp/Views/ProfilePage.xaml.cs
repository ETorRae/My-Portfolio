namespace CalramelApp.Views;

public partial class ProfilePage : ContentPage
{
    private Database.LocalDatabaseService databaseService;
    private Database.HistoryDatabase databaseHistory;
    private Models.PersonModel persons;
    private List<Models.PersonModel> personsList;
    private List<Models.HistoryDatabaseModel> personsHistory;
   
    public ProfilePage()
	{
		InitializeComponent();
        CheckData();
        DisplayFalse();
    }


    private void DisplayFalse()
    {
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        DisplayalertCheck.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        FlyoutMenuPage.TranslateTo(-310, 0);

    }
    private async void CheckData()
    {
        databaseService = new Database.LocalDatabaseService();
        persons = await databaseService.GetPersonByUsernameAsync(LoginPage.UsernameUse);

        DataText.Text = persons.Firstname + " " + persons.Lastname;

        CheckingData.Text = $"�  �ӹǳ˹��¤����������� {persons.CountLength.ToString()} ����";
        CheckingData2.Text = $"�  �ӹǳ˹��¾�鹷������� {persons.CountArea.ToString()} ����";
        CheckingData3.Text = $"�  �ӹǳ˹��¢�Ҵ����������� {persons.CountSizeData.ToString()} ����";

    }

    private async void Calculator_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculatorPage());
        DisplayFalse();
    }

    private async void History_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void Profile_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ProfilePage());
        DisplayFalse();
    }

    private void CheckDisplay(bool check)
    {
        DeleteButton.IsEnabled = check;
        hamburger.IsEnabled = check;
        Calculator.IsEnabled = check;
        History.IsEnabled = check;
        Profile.IsEnabled = check;
        HomeButton.IsEnabled = check;
        Logout.IsEnabled = check;
    }
    private async void Logout_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);
        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        AlertLogout.Opacity = 0;
        AlertLogout.IsVisible = true;
        await AlertLogout.FadeTo(1, 200);
    }

    private async void HomeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new MainPage());
        DisplayFalse();
    }

    private async void ReturnButton_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);

        BackgroundDisplayalert.FadeTo(0, 200);
        await Displayalert.FadeTo(0, 200);
        BackgroundAlertLogout.FadeTo(0, 200);
        await AlertLogout.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
    }
    private async void LogoutRealButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void DeleteButton_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);

        BackgroundDisplayalert.Opacity = 0;
        BackgroundDisplayalert.IsVisible = true;
        BackgroundDisplayalert.FadeTo(0.5, 200);
        Displayalert.Opacity = 0;
        Displayalert.IsVisible = true;
        await Displayalert.FadeTo(1, 200);

        AlertText.Text = persons.Username + " ������ҧ���� !";

    }



    private async void DeleteRealButton_Clicked(object sender, EventArgs e)
    {
        databaseService = new Database.LocalDatabaseService();
        personsList = await databaseService.GetPersonByUsernameList(LoginPage.UsernameUse);

        databaseHistory = new Database.HistoryDatabase();
        personsHistory = await databaseHistory.GetPersonByUsernameAsync(LoginPage.UsernameUse);

        foreach (var person in personsList)
        {
            await databaseService.DeleteItemAsync(person);
        }

        foreach (var person in personsHistory)
        {
            await databaseHistory.DeleteItemAsync(person);
        }
        CheckDisplay(false);

        Displayalert.FadeTo(0, 200);
        Displayalert.IsVisible = false;


        DisplayalertCheck.Opacity = 0;
        DisplayalertCheck.IsVisible = true;
        await DisplayalertCheck.FadeTo(1, 200);

    }

    private async void CheckButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private void hamburger_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);
        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        FlyoutMenuPage.TranslateTo(0, 0);
    }

    private void ReturnButtonFrame_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        BackgroundAlertLogout.FadeTo(0, 200);
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private async void LengthFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteLengthPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void AreaFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteAreaPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void SizeDataFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteSizeArea());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void LengthHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void AreaHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void SizeDataHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
        CheckDisplay(true);
    }
}