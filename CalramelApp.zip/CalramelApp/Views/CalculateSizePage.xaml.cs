namespace CalramelApp.Views;

public partial class CalculateSizePage : ContentPage
{
    public string Category { get; set; }
    public string About { get; set; }
    public string Description { get; set; }
    public string Value { get; set; }
    public string MenuFrom { get; set; }
    public int MenuFromNumber { get; set; }

    public string MenuConvert { get; set; }
    public int MenuConvertNumber { get; set; }

    public string SizeData { get; set; } = "SizeData";
    public string DateString { get; set; }
    public string TimeString { get; set; }

    public int Checking { get; set; }
    private readonly Database.HistoryDatabase DatabaseService;
    private Models.HistoryDatabaseModel FixedModel;
    public CalculateSizePage(string category, string about, string description)
    {
        InitializeComponent();

        Checking = 0;
        DatabaseService = new Database.HistoryDatabase();
        Category = category;
        About = about;
        Description = description;
        DisplayFalse();
    }

    public CalculateSizePage(Models.HistoryDatabaseModel Fixed)
    {
        InitializeComponent();

        Checking = 1;
        DatabaseService = new Database.HistoryDatabase();
        Category = Fixed.Category;
        About = Fixed.About;
        Description = Fixed.Description;


        ValueNumber.Text = Fixed.ValueNumber;
        DropdownMenuFromButton.Text = Fixed.MenuFrom;
        DropdownMenuConvertButton.Text = Fixed.MenuConvert;

        MenuFrom = DropdownMenuFromButton.Text;
        MenuConvert = DropdownMenuConvertButton.Text;
        Value = ValueNumber.Text;
        MenuFromNumber = Fixed.NumberFrom;
        MenuConvertNumber = Fixed.NumberConvert;

        FixedModel = Fixed;
        DisplayFalse();
    }

    private void DisplayFalse()
    {
        DisplayalertCheckMap.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private void DropdownMenuFromButton_Clicked(object sender, EventArgs e)
    {

        if (DropdownMenuFrom.IsVisible == true)
        {
            DropdownMenuFrom.IsVisible = false;
        }

        else
        {
            DropdownMenuFrom.IsVisible = true;
            DropdownMenuConvert.IsVisible = false;
        }

    }

    private void DropdownMenuConvertButton_Clicked(object sender, EventArgs e)
    {
        if (DropdownMenuConvert.IsVisible == true)
        {
            DropdownMenuConvert.IsVisible = false;
        }

        else
        {
            DropdownMenuConvert.IsVisible = true;
            DropdownMenuFrom.IsVisible = false;
        }
    }

    private void CategoryFrom1_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 0;
        MenuFrom = CategoryFrom1.Text;
        DropdownMenuFromButton.Text = CategoryFrom1.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom2_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 1;
        MenuFrom = CategoryFrom2.Text;
        DropdownMenuFromButton.Text = CategoryFrom2.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom3_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 2;
        MenuFrom = CategoryFrom3.Text;
        DropdownMenuFromButton.Text = CategoryFrom3.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom4_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 3;
        MenuFrom = CategoryFrom4.Text;
        DropdownMenuFromButton.Text = CategoryFrom4.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom5_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 4;
        MenuFrom = CategoryFrom5.Text;
        DropdownMenuFromButton.Text = CategoryFrom5.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom6_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 5;
        MenuFrom = CategoryFrom6.Text;
        DropdownMenuFromButton.Text = CategoryFrom6.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom7_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 6;
        MenuFrom = CategoryFrom7.Text;
        DropdownMenuFromButton.Text = CategoryFrom7.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom8_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 7;
        MenuFrom = CategoryFrom8.Text;
        DropdownMenuFromButton.Text = CategoryFrom8.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom9_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 8;
        MenuFrom = CategoryFrom9.Text;
        DropdownMenuFromButton.Text = CategoryFrom9.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom10_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 9;
        MenuFrom = CategoryFrom10.Text;
        DropdownMenuFromButton.Text = CategoryFrom10.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom11_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 10;
        MenuFrom = CategoryFrom11.Text;
        DropdownMenuFromButton.Text = CategoryFrom11.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert1_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 0;
        MenuConvert = CategoryConvert1.Text;
        DropdownMenuConvertButton.Text = CategoryConvert1.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;

    }

    private void CategoryConvert2_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 1;
        MenuConvert = CategoryConvert2.Text;
        DropdownMenuConvertButton.Text = CategoryConvert2.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert3_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 2;
        MenuConvert = CategoryConvert3.Text;
        DropdownMenuConvertButton.Text = CategoryConvert3.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert4_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 3;
        MenuConvert = CategoryConvert4.Text;
        DropdownMenuConvertButton.Text = CategoryConvert4.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert5_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 4;
        MenuConvert = CategoryConvert5.Text;
        DropdownMenuConvertButton.Text = CategoryConvert5.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert6_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 5;
        MenuConvert = CategoryConvert6.Text;
        DropdownMenuConvertButton.Text = CategoryConvert6.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert7_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 6;
        MenuConvert = CategoryConvert7.Text;
        DropdownMenuConvertButton.Text = CategoryConvert7.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert8_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 7;
        MenuConvert = CategoryConvert8.Text;
        DropdownMenuConvertButton.Text = CategoryConvert8.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert9_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 8;
        MenuConvert = CategoryConvert9.Text;
        DropdownMenuConvertButton.Text = CategoryConvert9.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert10_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 9;
        MenuConvert = CategoryConvert10.Text;
        DropdownMenuConvertButton.Text = CategoryConvert10.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert11_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 10;
        MenuConvert = CategoryConvert11.Text;
        DropdownMenuConvertButton.Text = CategoryConvert11.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private async void ResultButton_Clicked(object sender, EventArgs e)
    {
        double number;

        Database.LocalDatabaseService DatabaseServiceC = new Database.LocalDatabaseService();
        Models.PersonModel person = await DatabaseServiceC.GetPersonByUsernameAsync(LoginPage.UsernameUse);

        if (ValueNumber.Text == null || !double.TryParse(ValueNumber.Text, out number))
        {
            AlertValueNumber.Text = "�ô��͹���੾�е���Ţ㹪�ͧ�����ҹ�� !";


            AlertMenuFrom.Text = null;
            AlertMenuConvert.Text = null;

        }

        else if (DropdownMenuFromButton.Text != MenuFrom)
        {
            AlertValueNumber.Text = null;
            AlertMenuConvert.Text = null;

            AlertMenuFrom.Text = "�ô���͡˹��¤�����Ƿ����";
        }

        else if (DropdownMenuConvertButton.Text != MenuConvert)
        {
            AlertValueNumber.Text = null;
            AlertMenuFrom.Text = null;

            AlertMenuConvert.Text = "�ô���͡˹��¤�����Ƿ���ͧ��è��ŧ";

        }

        else
        {
            AlertValueNumber.Text = null;
            AlertMenuFrom.Text = null;
            AlertMenuConvert.Text = null;

            Date();
            Time();

            Value = ValueNumber.Text;
            double NumberResult = ConvertSizeData(Double.Parse(Value), MenuFromNumber, MenuConvertNumber);
            ResultTextCheck.Text = $"{NumberResult.ToString()} {MenuConvert}";


            if (Checking == 1)
            {
                await DatabaseService.DeleteItemAsync(FixedModel);
            }


            await DatabaseService.SaveItemAsync(new Models.HistoryDatabaseModel
            {
                Username = LoginPage.UsernameUse,
                Category = this.Category,
                About = this.About,
                Description = this.Description,
                ValueNumber = this.Value,
                MenuFrom = this.MenuFrom,
                Result = NumberResult.ToString(),
                MenuConvert = this.MenuConvert,
                Date = this.DateString + "  -  " + this.TimeString,
                Time = this.TimeString,
                Name = SizeData,
                ImagePath = "cal3",
                NumberFrom = MenuFromNumber,
                NumberConvert = MenuConvertNumber,
            });

            person.CountSizeData += 1;
            await DatabaseServiceC.SaveItemAsync(person);

            BackgroundAlertLogout.Opacity = 0;
            BackgroundAlertLogout.IsVisible = true;
            BackgroundAlertLogout.FadeTo(0.5, 200);
            DisplayalertCheckMap.Opacity = 0;
            DisplayalertCheckMap.IsVisible = true;
            await DisplayalertCheckMap.FadeTo(1, 200);

        }
    }
    private void Date()
    {
        DateTime currentDateTime = DateTime.Now;

        string formattedDate = currentDateTime.ToString("dd/MM/yyyy");

        this.DateString = formattedDate;
    }

    private void Time()
    {
        DateTime currentDateTime = DateTime.Now;

        string formattedTime = currentDateTime.ToString("hh:mm tt");

        this.TimeString = formattedTime;
    }
    private static double ConvertSizeData(double length, int fromUnit, int toUnit)
    {
        double[] conversionFactors = 
        {
            1, // ��ҺԵ (Tbit)
            1.073941888079786e-7, // Tebibytes (TiB)
            0.125, // �Ժ��� (Nibbles)
            8, // 亵� (B)
            1, // �Ե (Bit)
            1.152921504606847e-18, // ��硫�亵� (EB)
            8e12, // Exabits (Ebit)
            1.024, // Exbibytes (EiB)
            1e-9, // �ԡ�亵� (GB)
            8e-9, // �ԡкԵ (Gbit)
            8.589934592e9, // Gibibytes (GiB)
            1e-6, // ����亵� (KB)
            8e-6, // ���źԵ (Kbit)
            1.024e-7, // Kibibytes (KiB)
            1e-12, // ����亵� (MB)
            8e-12, // ���кԵ (Mbit)
            1.048576e-9, // Mebibytes (MiB)
            1e-15, // ྵ�亵� (PB)
            8e-15, // ྵкԵ (Pbit)
            1.125899906884629e-12, // Pebibytes (PiB)
            1e-12 // ���亵� (TB)
        };


        double result = length * conversionFactors[fromUnit] / conversionFactors[toUnit];
        return result;
    }

    private async void Calculator_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculatorPage());
        DisplayFalse();
    }

    private async void History_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void Profile_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ProfilePage());
        DisplayFalse();
    }

    private void CheckDisplay(bool check)
    {
        hamburger.IsEnabled = check;
        DropdownMenuFrom.IsVisible = check;
        DropdownMenuConvert.IsVisible = check;
        ValueNumber.IsEnabled = check;
        DropdownMenuFromButton.IsEnabled = check;
        DropdownMenuConvertButton.IsEnabled = check;
        Calculator.IsEnabled = check;
        History.IsEnabled = check;
        Profile.IsEnabled = check;
        HomeButton.IsEnabled = check;
        Logout.IsEnabled = check;
        MenuConvertCheck.IsEnabled = check;
        MenuConvertFrom.IsEnabled = check;
        ResultButton.IsEnabled = check;
    }

    private async void Logout_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        AlertLogout.Opacity = 0;
        AlertLogout.IsVisible = true;
        await AlertLogout.FadeTo(1, 200);
    }



    private async void HomeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new MainPage());
        DisplayFalse();
    }

    private void ReturnButton_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        AlertLogout.FadeTo(0, 200);
    }
    private async void LogoutRealButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom12_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 11;
        MenuFrom = CategoryFrom12.Text;
        DropdownMenuFromButton.Text = CategoryFrom12.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom13_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 12;
        MenuFrom = CategoryFrom13.Text;
        DropdownMenuFromButton.Text = CategoryFrom13.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom14_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 13;
        MenuFrom = CategoryFrom14.Text;
        DropdownMenuFromButton.Text = CategoryFrom14.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom15_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 14;
        MenuFrom = CategoryFrom15.Text;
        DropdownMenuFromButton.Text = CategoryFrom15.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom16_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 15;
        MenuFrom = CategoryFrom16.Text;
        DropdownMenuFromButton.Text = CategoryFrom16.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom17_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 16;
        MenuFrom = CategoryFrom17.Text;
        DropdownMenuFromButton.Text = CategoryFrom17.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom18_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 17;
        MenuFrom = CategoryFrom18.Text;
        DropdownMenuFromButton.Text = CategoryFrom18.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom19_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 18;
        MenuFrom = CategoryFrom19.Text;
        DropdownMenuFromButton.Text = CategoryFrom19.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom20_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 19;
        MenuFrom = CategoryFrom20.Text;
        DropdownMenuFromButton.Text = CategoryFrom20.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom21_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 20;
        MenuFrom = CategoryFrom21.Text;
        DropdownMenuFromButton.Text = CategoryFrom21.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert12_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 11;
        MenuConvert = CategoryConvert12.Text;
        DropdownMenuConvertButton.Text = CategoryConvert12.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert13_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 12;
        MenuConvert = CategoryConvert13.Text;
        DropdownMenuConvertButton.Text = CategoryConvert13.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert14_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 13;
        MenuConvert = CategoryConvert14.Text;
        DropdownMenuConvertButton.Text = CategoryConvert14.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert15_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 14;
        MenuConvert = CategoryConvert15.Text;
        DropdownMenuConvertButton.Text = CategoryConvert15.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert16_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 15;
        MenuConvert = CategoryConvert16.Text;
        DropdownMenuConvertButton.Text = CategoryConvert16.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert17_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 16;
        MenuConvert = CategoryConvert17.Text;
        DropdownMenuConvertButton.Text = CategoryConvert17.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert18_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 17;
        MenuConvert = CategoryConvert18.Text;
        DropdownMenuConvertButton.Text = CategoryConvert18.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert19_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 18;
        MenuConvert = CategoryConvert19.Text;
        DropdownMenuConvertButton.Text = CategoryConvert19.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert20_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 19;
        MenuConvert = CategoryConvert20.Text;
        DropdownMenuConvertButton.Text = CategoryConvert20.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert21_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 20;
        MenuConvert = CategoryConvert21.Text;
        DropdownMenuConvertButton.Text = CategoryConvert21.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private async void CheckMapButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
    }

    private void hamburger_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        FlyoutMenuPage.TranslateTo(0, 0);
    }

    private void ReturnButtonFrame_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private async void LengthFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteLengthPage());
        DisplayFalse();
    }

    private async void AreaFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteAreaPage());
        DisplayFalse();
    }

    private async void SizeDataFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteSizeArea());
        DisplayFalse();
    }

    private async void LengthHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void AreaHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
    }

    private async void SizeDataHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
    }
}