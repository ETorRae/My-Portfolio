namespace CalramelApp.Views;

public partial class ForgotPage : ContentPage
{
    private readonly Database.LocalDatabaseService DatabaseService;
    public ForgotPage()
	{
		InitializeComponent();
        DatabaseService = new Database.LocalDatabaseService();
        DisplayFalse();
    }

    private void DisplayFalse()
    {
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        DisplayalertFirstname.IsVisible = false;
        DisplayalertLastname.IsVisible = false;
        DisplayalertUsername.IsVisible = false;
        DisplayalertPassword.IsVisible = false;
        DisplayalertConfirmPassword.IsVisible = false;
    }
    private async void BackButton_Clicked(object sender, EventArgs e)
    {   
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
    }

    private async void ConfirmButton_Clicked(object sender, EventArgs e)
    {
        Models.PersonModel person = await DatabaseService.GetPersonByUsernameAsync(Username.Text);


        if (Firstname.Text == null || Firstname.Text.Length == 0)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertFirstname.Opacity = 0;
            DisplayalertFirstname.IsVisible = true;
            await DisplayalertFirstname.FadeTo(1, 200);
        }

        else if (Lastname.Text == null || Lastname.Text.Length == 0)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertLastname.Opacity = 0;
            DisplayalertLastname.IsVisible = true;
            await DisplayalertLastname.FadeTo(1, 200);

        }

        else if (Username.Text == null || Username.Text.Length == 0)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertUsername.Opacity = 0;
            DisplayalertUsername.IsVisible = true;
            await DisplayalertUsername.FadeTo(1, 200);

        }

        else if (Password.Text == null || Password.Text.Length == 0)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertPassword.Opacity = 0;
            DisplayalertPassword.IsVisible = true;
            await DisplayalertPassword.FadeTo(1, 200);
        }

        else if (person == null)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertUsername.Opacity = 0;
            DisplayalertUsername.IsVisible = true;
            await DisplayalertUsername.FadeTo(1, 200);
        }

        else if (person != null && person.Firstname != Firstname.Text)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertFirstname.Opacity = 0;
            DisplayalertFirstname.IsVisible = true;
            await DisplayalertFirstname.FadeTo(1, 200);
        }

        else if (person != null && person.Lastname != Lastname.Text)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayalertLastname.Opacity = 0;
            DisplayalertLastname.IsVisible = true;
            await DisplayalertLastname.FadeTo(1, 200);
        }


        else
        {
            if (Password.Text != ConfirmPassword.Text || ConfirmPassword.Text.Length == 0)
            {
                BackgroundDisplayalert.Opacity = 0;
                BackgroundDisplayalert.IsVisible = true;
                BackgroundDisplayalert.FadeTo(0.5, 200);
                DisplayalertConfirmPassword.Opacity = 0;
                DisplayalertConfirmPassword.IsVisible = true;
                await DisplayalertConfirmPassword.FadeTo(1, 200);
            }

            

            else if (person != null && person.Firstname == Firstname.Text && person.Lastname == Lastname.Text)
            {
                person.Password = Password.Text;

                await DatabaseService.SaveItemAsync(person);

                BackgroundDisplayalert.Opacity = 0;
                BackgroundDisplayalert.IsVisible = true;
                BackgroundDisplayalert.FadeTo(0.5, 200);
                Displayalert.Opacity = 0;
                Displayalert.IsVisible = true;
                await Displayalert.FadeTo(1, 200);

                await Task.Delay(2000);

                await Navigation.PushModalAsync(new LoginPage());
                DisplayFalse();

            }


        }

    }
    private async void FirstnameAlertButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertFirstname.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertFirstname.IsVisible = false;
    }

    private async void LastnameAlertButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertLastname.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertLastname.IsVisible = false;
    }

    private async void UsernameAlertButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertUsername.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertUsername.IsVisible = false;
    }

    private async void PasswordAlertButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertPassword.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertPassword.IsVisible = false;
    }

    private async void ConfirmPasswordAlertButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertConfirmPassword.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertConfirmPassword.IsVisible = false;
    }

}