using CalramelApp.Models;
using System;
using System.ComponentModel;
namespace CalramelApp.Views;

public partial class CalculateLengthPage : ContentPage
{
    public static int CountLength { get; set; }
    public string Category { get; set; }
    public string About { get; set; }
    public string Description { get; set; }
    public string Value { get; set; }
    public string MenuFrom { get; set; }
    public int MenuFromNumber { get; set; }

    public string MenuConvert { get; set; }
    public int MenuConvertNumber { get; set; }

    public string Length { get; set; }
    public string DateString { get; set; }
    public string TimeString { get; set; }

    public int Checking { get; set; }
    private readonly Database.HistoryDatabase DatabaseService;
    private Models.HistoryDatabaseModel FixedModel;
    public CalculateLengthPage(string category, string about, string description)
    {
        InitializeComponent();

        Checking = 0;
        DatabaseService = new Database.HistoryDatabase();
        Category = category;
        About = about;
        Description = description;
        Length = "Length";
        DisplayFalse();
    }

    public CalculateLengthPage(Models.HistoryDatabaseModel Fixed)
    {
        InitializeComponent();

        Checking = 1;
        DatabaseService = new Database.HistoryDatabase();
        Category = Fixed.Category;
        About = Fixed.About;
        Description = Fixed.Description;

        ValueNumber.Text = Fixed.ValueNumber;
        DropdownMenuFromButton.Text = Fixed.MenuFrom;
        DropdownMenuConvertButton.Text = Fixed.MenuConvert;

        MenuFrom = DropdownMenuFromButton.Text;
        MenuConvert = DropdownMenuConvertButton.Text;
        Value = ValueNumber.Text;

        MenuFromNumber = Fixed.NumberFrom;
        MenuConvertNumber = Fixed.NumberConvert;

        FixedModel = Fixed;
        Length = "Length";
        DisplayFalse();
    }

    private void DisplayFalse()
    {
        DisplayalertCheckMap.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private void DropdownMenuFromButton_Clicked(object sender, EventArgs e)
    {

        if (DropdownMenuFrom.IsVisible == true)
        {
            DropdownMenuFrom.IsVisible = false;
        }

        else
        {
            DropdownMenuFrom.IsVisible = true;
            DropdownMenuConvert.IsVisible = false;
        }

    }

    private void DropdownMenuConvertButton_Clicked(object sender, EventArgs e)
    {
        if (DropdownMenuConvert.IsVisible == true)
        {
            DropdownMenuConvert.IsVisible = false;
        }

        else
        {
            DropdownMenuConvert.IsVisible = true;
            DropdownMenuFrom.IsVisible = false;
        }
    }

    private void CategoryFrom1_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 0;
        MenuFrom = CategoryFrom1.Text;
        DropdownMenuFromButton.Text = CategoryFrom1.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom2_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 1;
        MenuFrom = CategoryFrom2.Text;
        DropdownMenuFromButton.Text = CategoryFrom2.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom3_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 2;
        MenuFrom = CategoryFrom3.Text;
        DropdownMenuFromButton.Text = CategoryFrom3.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom4_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 3;
        MenuFrom = CategoryFrom4.Text;
        DropdownMenuFromButton.Text = CategoryFrom4.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom5_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 4;
        MenuFrom = CategoryFrom5.Text;
        DropdownMenuFromButton.Text = CategoryFrom5.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom6_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 5;
        MenuFrom = CategoryFrom6.Text;
        DropdownMenuFromButton.Text = CategoryFrom6.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom7_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 6;
        MenuFrom = CategoryFrom7.Text;
        DropdownMenuFromButton.Text = CategoryFrom7.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom8_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 7;
        MenuFrom = CategoryFrom8.Text;
        DropdownMenuFromButton.Text = CategoryFrom8.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom9_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 8;
        MenuFrom = CategoryFrom9.Text;
        DropdownMenuFromButton.Text = CategoryFrom9.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom10_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 9;
        MenuFrom = CategoryFrom10.Text;
        DropdownMenuFromButton.Text = CategoryFrom10.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryFrom11_Clicked(object sender, EventArgs e)
    {
        MenuFromNumber = 10;
        MenuFrom = CategoryFrom11.Text;
        DropdownMenuFromButton.Text = CategoryFrom11.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert1_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 0;
        MenuConvert = CategoryConvert1.Text;
        DropdownMenuConvertButton.Text = CategoryConvert1.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;

    }

    private void CategoryConvert2_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 1;
        MenuConvert = CategoryConvert2.Text;
        DropdownMenuConvertButton.Text = CategoryConvert2.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert3_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 2;
        MenuConvert = CategoryConvert3.Text;
        DropdownMenuConvertButton.Text = CategoryConvert3.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert4_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 3;
        MenuConvert = CategoryConvert4.Text;
        DropdownMenuConvertButton.Text = CategoryConvert4.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert5_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 4;
        MenuConvert = CategoryConvert5.Text;
        DropdownMenuConvertButton.Text = CategoryConvert5.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert6_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 5;
        MenuConvert = CategoryConvert6.Text;
        DropdownMenuConvertButton.Text = CategoryConvert6.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert7_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 6;
        MenuConvert = CategoryConvert7.Text;
        DropdownMenuConvertButton.Text = CategoryConvert7.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert8_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 7;
        MenuConvert = CategoryConvert8.Text;
        DropdownMenuConvertButton.Text = CategoryConvert8.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert9_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 8;
        MenuConvert = CategoryConvert9.Text;
        DropdownMenuConvertButton.Text = CategoryConvert9.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert10_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 9;
        MenuConvert = CategoryConvert10.Text;
        DropdownMenuConvertButton.Text = CategoryConvert10.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private void CategoryConvert11_Clicked(object sender, EventArgs e)
    {
        MenuConvertNumber = 10;
        MenuConvert = CategoryConvert11.Text;
        DropdownMenuConvertButton.Text = CategoryConvert11.Text;
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private async void ResultButton_Clicked(object sender, EventArgs e)
    {
        double number;

        Database.LocalDatabaseService DatabaseServiceC = new Database.LocalDatabaseService();
        Models.PersonModel person = await DatabaseServiceC.GetPersonByUsernameAsync(LoginPage.UsernameUse);

        if (ValueNumber.Text == null || !double.TryParse(ValueNumber.Text, out number))
        {
            AlertValueNumber.Text = "�ô��͹���੾�е���Ţ㹪�ͧ�����ҹ�� !";

            AlertMenuFrom.Text = null;
            AlertMenuConvert.Text = null;

        }

        else if (DropdownMenuFromButton.Text != MenuFrom)
        {
            AlertValueNumber.Text = null;
            AlertMenuConvert.Text = null;

            AlertMenuFrom.Text = "�ô���͡˹��¤�����Ƿ����";
        }

        else if (DropdownMenuConvertButton.Text != MenuConvert)
        {
            AlertValueNumber.Text = null;
            AlertMenuFrom.Text = null;

            AlertMenuConvert.Text = "�ô���͡˹��¤�����Ƿ���ͧ��è��ŧ";

        }

        else
        {
            AlertValueNumber.Text = null;
            AlertMenuFrom.Text = null;
            AlertMenuConvert.Text = null;

            Date();
            Time();

            Value = ValueNumber.Text;
            double NumberResult = ConvertLength(Double.Parse(Value), MenuFromNumber, MenuConvertNumber);
            ResultTextCheck.Text = $"{NumberResult.ToString()} {MenuConvert}";


            if (Checking == 1)
            {
                await DatabaseService.DeleteItemAsync(FixedModel);
            }


            await DatabaseService.SaveItemAsync(new HistoryDatabaseModel
            {
                Username = LoginPage.UsernameUse,
                Category = this.Category,
                About = this.About,
                Description = this.Description,
                ValueNumber = this.Value,
                MenuFrom = this.MenuFrom,
                Result = NumberResult.ToString(),
                MenuConvert = this.MenuConvert,
                Date = this.DateString + "  -  " + this.TimeString,
                Time = this.TimeString,
                Name = Length,
                ImagePath = "cal1",
                NumberFrom = MenuFromNumber,
                NumberConvert = MenuConvertNumber,
            });

            person.CountLength += 1;
            await DatabaseServiceC.SaveItemAsync(person);

            BackgroundAlertLogout.Opacity = 0;
            BackgroundAlertLogout.IsVisible = true;
            BackgroundAlertLogout.FadeTo(0.5, 200);
            DisplayalertCheckMap.Opacity = 0;
            DisplayalertCheckMap.IsVisible = true;
            await DisplayalertCheckMap.FadeTo(1, 200);
        }




    }
    private void Date()
    {
        DateTime currentDateTime = DateTime.Now;

        string formattedDate = currentDateTime.ToString("dd/MM/yyyy");

        this.DateString = formattedDate;
    }

    private void Time()
    {
        DateTime currentDateTime = DateTime.Now;

        string formattedTime = currentDateTime.ToString("hh:mm tt");

        this.TimeString = formattedTime;
    }
    private static double ConvertLength(double length, int fromUnit, int toUnit)
    {
        double[] ratios = { 1e-9, 1e-6, 0.001, 0.01, 0.0254, 0.3048, 0.4572, 1, 1609.34, 1000, 1852 };

        double result = length * ratios[fromUnit] / ratios[toUnit];
        return result;
    }

    private async void Calculator_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculatorPage());
        DisplayFalse();
    }

    private async void History_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void Profile_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ProfilePage());
        DisplayFalse();
    }

    private void CheckDisplay(bool check)
    {
        hamburger.IsEnabled = check;
        DropdownMenuFrom.IsVisible = check;
        DropdownMenuConvert.IsVisible = check;
        ValueNumber.IsEnabled = check;
        DropdownMenuFromButton.IsEnabled = check;
        DropdownMenuConvertButton.IsEnabled = check;
        Calculator.IsEnabled = check;
        History.IsEnabled = check;
        Profile.IsEnabled = check;
        HomeButton.IsEnabled = check;
        Logout.IsEnabled = check;
        MenuConvertCheck.IsEnabled = check;
        MenuConvertFrom.IsEnabled = check;
        ResultButton.IsEnabled = check;
    }

    private async void Logout_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        AlertLogout.Opacity = 0;
        AlertLogout.IsVisible = true;
        await AlertLogout.FadeTo(1, 200);
    }



    private async void HomeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new MainPage());
        DisplayFalse();
    }

    private void ReturnButton_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        AlertLogout.FadeTo(0, 200);
    }
    private async void LogoutRealButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;
    }

    private async void CheckMapButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private void hamburger_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        FlyoutMenuPage.TranslateTo(0, 0);
    }

    private void ReturnButtonFrame_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        DropdownMenuFrom.IsVisible = false;
        DropdownMenuConvert.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        FlyoutMenuPage.TranslateTo(-310, 0);
    }
    private async void LengthFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteLengthPage());
        DisplayFalse();
    }

    private async void AreaFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteAreaPage());
        DisplayFalse();
    }

    private async void SizeDataFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteSizeArea());
        DisplayFalse();
    }

    private async void LengthHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void AreaHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
    }

    private async void SizeDataHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
    }
}