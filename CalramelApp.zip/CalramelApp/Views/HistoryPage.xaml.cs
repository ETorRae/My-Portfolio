using System.Collections.ObjectModel;

namespace CalramelApp.Views;

public partial class HistoryPage : ContentPage
{   
    ObservableCollection<Models.HistoryDatabaseModel> personsObservableCollection = new ObservableCollection<Models.HistoryDatabaseModel>();
    private readonly Database.HistoryDatabase DatabaseService;
    private Models.HistoryDatabaseModel CheckPerson;
    private Models.HistoryDatabaseModel Fixed;
    private int CheckingHamburger = 0;
    public HistoryPage()
    {
        InitializeComponent();

        DatabaseService = new Database.HistoryDatabase();
        DropdownMenuWindow.IsVisible = false;
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        DisplayFixed.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        ProcessDatabase();

    }

    private void DisplayFalse()
    {
        DropdownMenuWindow.IsVisible = false;
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        DisplayFixed.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private async void ProcessDatabase()
    {
        Database.HistoryDatabase databaseService = new Database.HistoryDatabase();
        List<Models.HistoryDatabaseModel> persons = await databaseService.GetPersonByUsernameAsync(LoginPage.UsernameUse);
        persons.Reverse();

        foreach (var person in persons)
        {   
            if (person.Name == "Length")
            {
                personsObservableCollection.Add(person);
            }
        }
       
        MyCollectionView.ItemsSource = personsObservableCollection;


    }

    private void DropdownMenu_Clicked(object sender, EventArgs e)
    {
        if (DropdownMenuWindow.IsVisible == false)
        {
            DropdownMenuWindow.IsVisible = true;
        }

        else
        {
            DropdownMenuWindow.IsVisible = false;
        }
    }

    private async void Category1_Clicked(object sender, EventArgs e)
    {
        DropdownMenu.Text = Category1.Text;
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void Category2_Clicked(object sender, EventArgs e)
    {
        DropdownMenu.Text = Category2.Text;
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
    }

    private async void Category3_Clicked(object sender, EventArgs e)
    {
        DropdownMenu.Text = Category3.Text;
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
    }
    private void CheckDisplay(bool check)
    {
        hamburger.IsEnabled = check;
        DropdownMenu.IsEnabled = check;
        searchText.IsEnabled = check;
        DropdownMenuWindow.IsVisible = check;
        Calculator.IsEnabled = check;
        History.IsEnabled = check;
        Profile.IsEnabled = check;
        HomeButton.IsEnabled = check;
        Logout.IsEnabled = check;
        MenuCheck.IsEnabled = check;
    }
    private async void DeleteButton_Clicked(object sender, EventArgs e)
    {   
        if (this.CheckingHamburger != 1)
        {
            var itemToDelete = (sender as Button).BindingContext as Models.HistoryDatabaseModel;
            CheckPerson = itemToDelete;
            CheckDisplay(false);

            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            Displayalert.Opacity = 0;
            Displayalert.IsVisible = true;
            await Displayalert.FadeTo(1, 200);
            AlertText.Text = itemToDelete.About;
        }
    }

    private async void DeleteRealButton_Clicked(object sender, EventArgs e)
    {
        await DatabaseService.DeleteItemAsync(CheckPerson);

        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
        this.CheckingHamburger = 0;
    }
    private async void ReturnButton_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 0;

        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;

        BackgroundDisplayalert.FadeTo(0, 200);
        await Displayalert.FadeTo(0, 200);
        await DisplayFixed.FadeTo(0, 200);
        BackgroundAlertLogout.FadeTo(0, 200);
        await AlertLogout.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        DisplayFixed.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
    }
    private async void Logout_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 1;
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        AlertLogout.Opacity = 0;
        AlertLogout.IsVisible = true;
        await AlertLogout.FadeTo(1, 200);
    }

    private async void Calculator_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculatorPage());
        DisplayFalse();
    }

    private async void History_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void Profile_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ProfilePage());
        DisplayFalse();
    }

    private async void HomeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new MainPage());
        DisplayFalse();
    }
    private async void LogoutRealButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
        this.CheckingHamburger = 0;
    }

    private async void DescriptionButton_Clicked(object sender, EventArgs e)
    {
        if (this.CheckingHamburger != 1)
        {
            CheckDisplay(false);

            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            DisplayFixed.Opacity = 0;
            DisplayFixed.IsVisible = true;
            await DisplayFixed.FadeTo(1, 200);

            var item = (sender as Button).BindingContext as Models.HistoryDatabaseModel;
            Fixed = item;

            TextCategory.Text = item.Category;
            TextAbout.Text = item.About;
            DescriptionText.Text = item.Description;
            ResultText.Text = $"�ҡ {item.ValueNumber} {item.MenuFrom}";
            ResultText2.Text = $"�ŧ�� {item.Result} {item.MenuConvert}";
        }

    }

    private async void FixedButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculateLengthPage(Fixed));
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

    private void searchText_TextChanged(object sender, TextChangedEventArgs e)
    {
        searchText.TextChanged += (sender, args) =>
        {
            ProcessDatabaseAsync(searchText.Text);
        };

    }
    private async Task ProcessDatabaseAsync(string searchText)
    {
        var databaseService = new Database.HistoryDatabase();
        var persons = await databaseService.GetPersonByUsernameAsync(LoginPage.UsernameUse);
        persons.Reverse();

        personsObservableCollection.Clear();

        foreach (var person in persons)
        {
            if (person.About.ToLowerInvariant().Contains(searchText.ToLowerInvariant()) && person.Name == "Length")
            {
                personsObservableCollection.Add(person);
            }
            
        }
       

        MyCollectionView.ItemsSource = personsObservableCollection;
    }

    private void hamburger_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);
        this.CheckingHamburger = 1;
        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        FlyoutMenuPage.TranslateTo(0, 0);
    }

    private void ReturnButtonFrame_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 0;
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private async void LengthFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteLengthPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

    private async void AreaFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteAreaPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

    private async void SizeDataFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteSizeArea());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

    private async void LengthHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

    private async void AreaHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

    private async void SizeDataHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenuWindow.IsVisible = false;
    }

}