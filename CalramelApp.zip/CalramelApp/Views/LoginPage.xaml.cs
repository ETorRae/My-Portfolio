namespace CalramelApp.Views;

public partial class LoginPage : ContentPage
{
    public static string UsernameUse;
	public LoginPage()
	{
		InitializeComponent();
        DisplayFalse();
    }

    private void DisplayFalse()
    {
        BackgroundDisplayalert.IsVisible = false;
        Displayalert.IsVisible = false;
        DisplayalertPassword.IsVisible = false;
        DisplayalertUsername.IsVisible = false;
        DisplayalertCheckMap.IsVisible = false;
    }
    private async void SignupButton_Clicked(object sender, EventArgs e)
    {   
        
		await Navigation.PushModalAsync(new SignupPage());
        DisplayFalse();
    }

    private async void ForgotPasswordButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ForgotPage());
        DisplayFalse();
    }

    private async void LoginButton_Clicked(object sender, EventArgs e)
    {
        Database.LocalDatabaseService databaseService = new Database.LocalDatabaseService();

        Models.PersonModel person = await databaseService.GetPersonByUsernameAsync(Username.Text);

        UsernameUse = Username.Text;

        if (person != null && person.Password == Password.Text)
        {
            BackgroundDisplayalert.Opacity = 0;
            BackgroundDisplayalert.IsVisible = true;
            BackgroundDisplayalert.FadeTo(0.5, 200);
            Displayalert.Opacity = 0;
            Displayalert.IsVisible = true;
            await Displayalert.FadeTo(1, 200);

            await Task.Delay(2000);

            await Navigation.PushModalAsync(new MainPage());

            DisplayFalse();
        }
        else
        {

            if (person == null || Username.Text != person.Username || person.Username == null || Username.Text.Length == 0)
            {
                BackgroundDisplayalert.Opacity = 0;
                BackgroundDisplayalert.IsVisible = true;
                BackgroundDisplayalert.FadeTo(0.5, 200);
                DisplayalertUsername.Opacity = 0;
                DisplayalertUsername.IsVisible = true;
                await DisplayalertUsername.FadeTo(1, 200);
            }

            else if (Password.Text == null)
            {
                BackgroundDisplayalert.Opacity = 0;
                BackgroundDisplayalert.IsVisible = true;
                BackgroundDisplayalert.FadeTo(0.5, 200);
                DisplayalertPassword.Opacity = 0;
                DisplayalertPassword.IsVisible = true;
                await DisplayalertPassword.FadeTo(1, 200);
            }

            else
            {
                BackgroundDisplayalert.Opacity = 0;
                BackgroundDisplayalert.IsVisible = true;
                BackgroundDisplayalert.FadeTo(0.5, 200);
                DisplayalertCheckMap.Opacity = 0;
                DisplayalertCheckMap.IsVisible = true;
                await DisplayalertCheckMap.FadeTo(1, 200);
            }

        }
    }

    private async void PasswordAlertButton_Clicked(object sender, EventArgs e)
    {
        BackgroundDisplayalert.FadeTo(0, 200);
        DisplayalertPassword.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertPassword.IsVisible = false;
        
    }

    private async void UsernameAlertButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertUsername.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertUsername.IsVisible = false;
        await Navigation.PushModalAsync(new SignupPage());
    }

    private async void CheckMapButton_Clicked(object sender, EventArgs e)
    {
        await BackgroundDisplayalert.FadeTo(0, 200);
        await DisplayalertCheckMap.FadeTo(0, 200);
        BackgroundDisplayalert.IsVisible = false;
        DisplayalertCheckMap.IsVisible = false;
    }
}