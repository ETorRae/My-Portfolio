using CalramelApp.Models;
using System.Collections.ObjectModel;

namespace CalramelApp.Views;

public partial class CalculatorPage : ContentPage
{	
	public ObservableCollection<Models.CalculatorModel> nameCalculator {  get; set; }
    private int CheckingHamburger = 0;
    public CalculatorPage()
	{
		InitializeComponent();
		NameCalculator();
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        BindingContext = new { nameCalculator }; 
    }

    private void DisplayFalse()
    {
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        FlyoutMenuPage.TranslateTo(-310, 0);
    }
	private void NameCalculator()
	{
		nameCalculator = new ObservableCollection<CalculatorModel>
		{
			new CalculatorModel("cal1" , "�ӹǳ�ŧ˹��¤������" , "��˹�����ͧ�ѹ�֡˹��¤������"),
			new CalculatorModel("cal2" , "�ӹǳ�ŧ˹��¾�鹷��" , "��˹�����ͧ�ѹ�֡˹��¾�鹷��"),
			new CalculatorModel("cal3", "�ӹǳ�ŧ˹��¢�Ҵ������" , "��˹�����ͧ�ѹ�֡˹��¢�Ҵ������")
		};
	}

    private async void CalculatorButton_Clicked(object sender, EventArgs e)
    {
        if (sender is Button button && button.BindingContext is CalculatorModel nameCalculator && this.CheckingHamburger != 1)
        {
            if (nameCalculator.ImagePath == "cal1")
			{
				await Navigation.PushModalAsync(new NoteLengthPage());
			}

            else if (nameCalculator.ImagePath == "cal2")
            {
                await Navigation.PushModalAsync(new NoteAreaPage());
            }

            else if (nameCalculator.ImagePath == "cal3")
            {
                await Navigation.PushModalAsync(new NoteSizeArea());
            }
        }
    }
    private async void Calculator_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculatorPage());
        DisplayFalse();
    }

    private async void History_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
    }

    private async void Profile_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ProfilePage());
        DisplayFalse();
    }

    private void CheckDisplay(bool check)
    {
        hamburger.IsEnabled = check;
        Calculator.IsEnabled = check;
        History.IsEnabled = check;
        Profile.IsEnabled = check;
        HomeButton.IsEnabled = check;
        Logout.IsEnabled = check;
    }

    private async void Logout_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 1;
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        AlertLogout.Opacity = 0;
        AlertLogout.IsVisible = true;
        await AlertLogout.FadeTo(1, 200);
    }

    private async void HomeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new MainPage());
        DisplayFalse();
    }

    private void ReturnButton_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 0;
        CheckDisplay(true);
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        AlertLogout.FadeTo(0, 200);
    }
    private async void LogoutRealButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
        this.CheckingHamburger = 0;
    }

    private void hamburger_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 1;
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        FlyoutMenuPage.TranslateTo(0, 0);
        
    }

    private void ReturnButtonFrame_Clicked(object sender, EventArgs e)
    {
        this.CheckingHamburger = 0;
        CheckDisplay(true);

        BackgroundAlertLogout.FadeTo(0, 200);
        FlyoutMenuPage.TranslateTo(-310, 0);
    }
    private async void LengthFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteLengthPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void AreaFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteAreaPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void SizeDataFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteSizeArea());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void LengthHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void AreaHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
        CheckDisplay(true);
    }

    private async void SizeDataHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
        CheckDisplay(true);
    }
}