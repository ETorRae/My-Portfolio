namespace CalramelApp.Views;

public partial class NoteSizeArea : ContentPage
{
    public string Category { get; set; }
    public string About { get; set; }
    public string Description { get; set; }

    public NoteSizeArea()
    {
        InitializeComponent();
        DropdownMenu.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
    }

    private void DisplayFalse()
    {
        DropdownMenu.IsVisible = false;
        BackgroundAlertLogout.IsVisible = false;
        AlertLogout.IsVisible = false;
        FlyoutMenuPage.TranslateTo(-310, 0);
    }
    private void DropdownMenuButton_Clicked(object sender, EventArgs e)
    {
        if (DropdownMenu.IsVisible == false)
        {
            DropdownMenu.IsVisible = true;
        }

        else
        {
            DropdownMenu.IsVisible = false;
        }
    }

    private void Category1_Clicked(object sender, EventArgs e)
    {
        Category = Category1.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category2_Clicked(object sender, EventArgs e)
    {
        Category = Category2.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category3_Clicked(object sender, EventArgs e)
    {
        Category = Category3.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category4_Clicked(object sender, EventArgs e)
    {
        Category = Category4.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category5_Clicked(object sender, EventArgs e)
    {
        Category = Category5.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category6_Clicked(object sender, EventArgs e)
    {
        Category = Category6.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category7_Clicked(object sender, EventArgs e)
    {
        Category = Category7.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category8_Clicked(object sender, EventArgs e)
    {
        Category = Category8.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private void Category9_Clicked(object sender, EventArgs e)
    {
        Category = Category9.Text;
        DropdownMenuButton.Text = Category;
        DropdownMenu.IsVisible = false;
    }

    private async void NextButton_Clicked(object sender, EventArgs e)
    {
        if (DropdownMenuButton.Text != Category)
        {
            AlertCategory.Text = "�ô���͡��Ǣ����Ǵ���� !";
            LabelAbout.Margin = new Thickness(22, 25, 0, 0);

            AlertAbout.Text = null;
            AlertDescription.Text = null;
            LabelDescription.Margin = new Thickness(22, 20, 0, 0);
            NextButton.Margin = new Thickness(15, 20, 15, 0);
        }

        else if (AboutEntry.Text == null || AboutEntry.MaxLength == 0)
        {
            AlertAbout.Text = "�ô��͡�������������ͧ����ǡѺ��Ǣ�� !";
            LabelDescription.Margin = new Thickness(22, 30, 0, 0);

            AlertCategory.Text = null;
            AlertDescription.Text = null;

            LabelAbout.Margin = new Thickness(22, 15, 0, 0);
            NextButton.Margin = new Thickness(15, 20, 15, 0);


        }

        else if (DescriptionEntry.Text == null || DescriptionEntry.MaxLength == 0)
        {
            AlertDescription.Text = "�ô��͡��������������´ !";
            NextButton.Margin = new Thickness(15, 30, 15, 0);

            AlertAbout.Text = null;
            AlertCategory.Text = null;
            LabelAbout.Margin = new Thickness(22, 15, 0, 0);
            LabelDescription.Margin = new Thickness(22, 20, 0, 0);

        }

        else
        {
            About = AboutEntry.Text;
            Description = DescriptionEntry.Text;

            await Navigation.PushModalAsync(new CalculateSizePage(Category, About, Description));
            DisplayFalse();
        }


    }
    private async void Calculator_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new CalculatorPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void History_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void Profile_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new ProfilePage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void HomeButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new MainPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }
    private async void LogoutRealButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new LoginPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private void CheckDisplay(bool check)
    {
        DropdownMenu.IsVisible = check;
        MenuDownCheck.IsEnabled = check;
        DropdownMenuButton.IsEnabled = check;
        AboutEntry.IsEnabled = check;
        DescriptionEntry.IsEnabled = check;
        Calculator.IsEnabled = check;
        History.IsEnabled = check;
        Profile.IsEnabled = check;
        HomeButton.IsEnabled = check;
        Logout.IsEnabled = check;
        NextButton.IsEnabled = check;
        hamburger.IsEnabled = check;
    }
    private async void Logout_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);
        DropdownMenu.IsVisible = false;
        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        AlertLogout.Opacity = 0;
        AlertLogout.IsVisible = true;
        await AlertLogout.FadeTo(1, 200);
    }

    private void ReturnButton_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
        BackgroundAlertLogout.FadeTo(0, 200);
        AlertLogout.FadeTo(0, 200);
    }
    private void hamburger_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(false);

        BackgroundAlertLogout.Opacity = 0;
        BackgroundAlertLogout.IsVisible = true;
        BackgroundAlertLogout.FadeTo(0.5, 200);
        FlyoutMenuPage.TranslateTo(0, 0);

    }

    private void ReturnButtonFrame_Clicked(object sender, EventArgs e)
    {
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;

        BackgroundAlertLogout.FadeTo(0, 200);
        FlyoutMenuPage.TranslateTo(-310, 0);
    }

    private async void LengthFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteLengthPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void AreaFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteAreaPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void SizeDataFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new NoteSizeArea());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void LengthHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void AreaHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistoryAreaPage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }

    private async void SizeDataHisFrameButton_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushModalAsync(new HistorySizePage());
        DisplayFalse();
        CheckDisplay(true);
        DropdownMenu.IsVisible = false;
    }
}