﻿using SQLite;

namespace CalramelApp.Models
{
    [Table("person")]
    public class PersonModel
    {
        [PrimaryKey]
        [AutoIncrement]
        [Column("id")]
        public int Id { get; set; }

        [Column("firstname")]
        public string Firstname { get; set; }

        [Column("lastname")]
        public string Lastname { get; set; }
        [Column("username")]
        public string Username { get; set; }
        [Column("password")]
        public string Password { get; set; }
        [Column("countlength")]
        public int CountLength { get; set; }
        [Column("countarea")]
        public int CountArea { get; set; }
        [Column("countsizedata")]
        public int CountSizeData { get; set; }
    }
}
