﻿using SQLite;


namespace CalramelApp.Models
{
    [Table("history")]
    public class HistoryDatabaseModel
    {
        [PrimaryKey]
        [AutoIncrement]
        [Column("id")]

        public int Id { get; set; }
        [Column("username")]
        public string Username { get; set; }
        [Column("category")]
        public string Category { get; set; }
        [Column("about")]
        public string About { get; set; }
        [Column("description")]
        public string Description { get; set; }
        [Column("valuenumber")]
        public string ValueNumber { get; set; }
        [Column("menufrom")]
        public string MenuFrom { get; set; }
        [Column("result")]
        public string Result { get; set; }
        [Column("menuconvert")]
        public string MenuConvert { get; set; }
        [Column("date")]
        public string Date { get; set; }

        [Column("time")]
        public string Time { get; set; }

        [Column("name")]
        public string Name { get; set; }
        [Column("imagepath")]
        public string ImagePath { get; set; }
        [Column("numberfrom")]
        public int NumberFrom { get; set; }
        [Column("numberconvert")]
        public int NumberConvert { get; set; }
    }
}
