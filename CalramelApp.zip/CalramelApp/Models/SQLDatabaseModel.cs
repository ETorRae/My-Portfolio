﻿namespace CalramelApp.Models
{
    public static class SQLDatabaseModel
    {
        public const string DatabaseName = "database_local.d3";

        public const SQLite.SQLiteOpenFlags Flags =
           SQLite.SQLiteOpenFlags.ReadWrite |
           SQLite.SQLiteOpenFlags.Create |
           SQLite.SQLiteOpenFlags.SharedCache;
        public static string DatabasePath =>
            Path.Combine(FileSystem.AppDataDirectory, DatabaseName);



    }
}
