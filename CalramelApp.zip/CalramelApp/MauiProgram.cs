﻿using Microsoft.Extensions.Logging;

namespace CalramelApp
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("ChakraPetch-Bold.ttf", "ChakraPetchBold");
                    fonts.AddFont("ChakraPetch-BoldItalic.ttf", "ChakraPetchBoldItalic");
                    fonts.AddFont("ChakraPetch-Italic.ttf", "ChakraPetchItalic");
                    fonts.AddFont("ChakraPetch-Light.ttf", "ChakraPetchLight");
                    fonts.AddFont("ChakraPetch-LightItalic.ttf", "ChakraPetchLightItalic");
                    fonts.AddFont("ChakraPetch-Medium.ttf", "ChakraPetchMedium");
                    fonts.AddFont("ChakraPetch-MediumItalic.ttf", "ChakraPetchMediumItalic");
                    fonts.AddFont("ChakraPetch-Regular.ttf", "ChakraPetchRegular");
                    fonts.AddFont("ChakraPetch-SemiBold.ttf", "ChakraPetchSemiBold");
                    fonts.AddFont("ChakraPetch-SemiBoldItalic.ttf", "ChakraPetchSemiBoldItalic");
                });
            builder.Services.AddSingleton<Database.LocalDatabaseService>();
            builder.Services.AddSingleton<Database.HistoryDatabase>();
            builder.Services.AddTransient<Views.SignupPage>();
            builder.Services.AddTransient<Views.ForgotPage>();
            builder.Services.AddTransient<Views.HistoryPage>();

#if DEBUG
            builder.Logging.AddDebug();
#endif
            Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping(nameof(Entry), (handler, view) =>
            {
#if ANDROID
                handler.PlatformView.SetBackgroundColor(Android.Graphics.Color.Transparent);
#endif
            });
            return builder.Build();
        }
    }
}
