﻿using SQLite;

namespace CalramelApp.Database
{
    public class HistoryDatabase
    {
        SQLiteAsyncConnection Database;
        async Task Init()
        {
            if (Database is not null)
                return;

            Database = new SQLiteAsyncConnection(Models.SQLDatabaseHistory.DatabasePath, Models.SQLDatabaseHistory.Flags);
            var result = await Database.CreateTableAsync<Models.HistoryDatabaseModel>();
        }
        public async Task<List<Models.HistoryDatabaseModel>> GetPersonByUsernameAsync(string username)
        {
            await Init();
            return await Database.Table<Models.HistoryDatabaseModel>().Where(p => p.Username == username).ToListAsync();
        }

        public async Task<int> SaveItemAsync(Models.HistoryDatabaseModel item)
        {
            await Init();
            if (item.Id != 0)
                return await Database.UpdateAsync(item);
            else
                return await Database.InsertAsync(item);
        }
        public async Task<int> DeleteItemAsync(Models.HistoryDatabaseModel item)
        {
            await Init();
            return await Database.DeleteAsync(item);
        }


    }
}
