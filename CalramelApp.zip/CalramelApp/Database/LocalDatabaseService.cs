﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalramelApp.Database
{
    public class LocalDatabaseService
    {
        SQLiteAsyncConnection Database;
        async Task Init()
        {
            if (Database is not null)
                return;

            Database = new SQLiteAsyncConnection(Models.SQLDatabaseModel.DatabasePath, Models.SQLDatabaseModel.Flags);
            var result = await Database.CreateTableAsync<Models.PersonModel>();
        }
        public async Task<Models.PersonModel> GetPersonByUsernameAsync(string username)
        {
            await Init();
            return await Database.Table<Models.PersonModel>().Where(p => p.Username == username).FirstOrDefaultAsync();
        }

        public async Task<List<Models.PersonModel>> GetPersonByUsernameList(string username)
        {
            await Init();
            return await Database.Table<Models.PersonModel>().Where(p => p.Username == username).ToListAsync();
        }

        public async Task<int> SaveItemAsync(Models.PersonModel item)
        {
            await Init();
            if (item.Id != 0)
                return await Database.UpdateAsync(item);
            else
                return await Database.InsertAsync(item);
        }
        public async Task<int> DeleteItemAsync(Models.PersonModel item)
        {
            await Init();
            return await Database.DeleteAsync(item);
        }

    }
}
